package com.sriindu.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sriindu.project.entity.College;
import com.sriindu.project.repository.CollegeRepository;

@Service
public class CollegeServiceImpl implements CollegeService{
	
	@Autowired
	CollegeRepository cr;

	@Override
	public College addCollege(College college) {
		// TODO Auto-generated method stub
		return cr.save(college);
	}

	@Override
	public List<College> fetchCollegeList() {
		// TODO Auto-generated method stub
		return cr.findAll();
	}

	@Override
	public College searchCollegeById(Long id) {
		// TODO Auto-generated method stub
		return cr.findById(id).get();
	}

	@Override
	public void deleteCollegeById(Long id) {
		// TODO Auto-generated method stub
		cr.deleteById(id);
	}

	@Override
	public College updateDepartment(College college, Long id) {
		// TODO Auto-generated method stub
		
		College collegeDB = cr.findById(id) .get();
		collegeDB.setCollegeName( 
                college.getCollegeName());
		collegeDB.setLocation( 
                college.getLocation());
		return cr.save(collegeDB);
	}


}
