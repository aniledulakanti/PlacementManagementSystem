package com.sriindu.project.service;

import java.util.List;

import com.sriindu.project.entity.College;

public interface CollegeService {

	College addCollege(College college);

	List<College> fetchCollegeList();

	College searchCollegeById(Long id);

	void deleteCollegeById(Long id);

	College updateDepartment(College college, Long id);
	
}
