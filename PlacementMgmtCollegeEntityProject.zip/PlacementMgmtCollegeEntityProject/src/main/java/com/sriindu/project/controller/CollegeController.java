package com.sriindu.project.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sriindu.project.entity.College;
import com.sriindu.project.service.CollegeService;

@RestController
public class CollegeController {
	
	@Autowired
	CollegeService cs ;
	
	@PostMapping("/college")
	public College addCollege(@RequestBody College college) {
		return cs.addCollege(college);
	}
	
	@GetMapping("/college")
    public List<College> fetchCollegeList() {
        return cs.fetchCollegeList();
    }
	
    @GetMapping("/college/{id}")
    public College searchCollegeById(@PathVariable("id") Long id)
            {
        return cs.searchCollegeById(id);
    }
	
    @DeleteMapping("/college/{id}")
    public String deleteCollegeById(@PathVariable("id") Long id) {
        cs.deleteCollegeById(id);
        return "College deleted Successfully!!";
    }
    
    @PutMapping("/college/{id}") 
    public College 
    updateDepartment(@RequestBody College college, 
                     @PathVariable("id") Long id) 
    { 
        return cs.updateDepartment( 
            college, id); 
    } 
    
}
